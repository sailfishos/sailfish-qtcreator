#include "%{ProjectName}.h"


#include <QCoreApplication>

//#include <contentaction5/contentaction.h>

%{ProjectName}::%{ProjectName}(QObject *parent) : QObject(parent)
{

}

void %{ProjectName}::start()
{

}

void %{ProjectName}::launchApp(const QString &appName, const QStringList &arguments)
{

}
